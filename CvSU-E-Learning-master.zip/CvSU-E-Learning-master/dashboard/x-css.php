    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../assets/plugins/datatables/datatables.min.css"/>
    <!-- include the style -->
    <link rel="stylesheet" href="../assets/plugins/alertifyjs/css/alertify.min.css" />
    <!-- include a theme -->
    <link rel="stylesheet" href="../assets/plugins/alertifyjs/css/themes/default.min.css" />
    <link href="../assets/css/icomoon/styles.css" rel="stylesheet" type="text/css">
      <style>
   
        .breadcrumb-item+.breadcrumb-item::before {
            display: inline-block;
            padding-right: .5rem;
            color: #ffffff;
            content: "/";
        }
        .bcrum{
            background-color:#4caf50 ;
        }
        .bcrum_i_a{
            color:white !important;
        }
        .bcrum_i_ac{
            color:#e4e3e4 !important;
        }
        .sidebar .nav-link.active{
        	background-color:#495057;
        }

        .uctext 
        {
            text-transform: uppercase;
        }

    </style>
    